# Excel Data Cleaning Project 

This project demonstrates how to clean and prepare a raw dataset using both **Excel** and **Python (Pandas)**. The dataset includes common issues like missing values, duplicates, inconsistent text formats, and incorrect data types.

## Tools Used
- Excel
- Python (Pandas)

## Folder Structure

excel-data-cleaning/
    raw_data/
    cleaned_data/
    README.md
python-data-cleaning/
    raw_data/
    cleaned_data/
    code/
     data_cleaning.py
    README.md


##   Task Summary
- Identified and handled missing values
- Removed duplicate rows
- Standardized inconsistent text values (e.g., gender, country names)
- Fixed column headers (lowercase, underscores)
- Converted date columns to consistent format
- Ensured data types were correct (e.g., int for age, datetime for dates)

##   Dataset
Dataset used: `amazon.csv` (from Kaggle)

##   How to Run
1. Open `data_cleaning.py` in a Python environment (VS Code, Jupyter, etc.)
2. Make sure `amazon.csv` is placed inside `python-data-cleaning/raw_data/`
3. Run the script to generate a cleaned CSV file in `python-data-cleaning/cleaned_data/`
