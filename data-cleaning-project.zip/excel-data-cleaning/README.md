#   Data Cleaning in Excel

This folder contains the Excel-based data cleaning work.

### Steps Performed:
- Identified missing values using filters
- Removed duplicates using "Remove Duplicates" tool
- Standardized text fields manually (e.g., gender to Male/Female)
- Cleaned and renamed column headers
- Checked and fixed data types manually
- Converted dates to a consistent format (dd-mm-yyyy)

> Screenshots folder is empty (steps were completed directly).
