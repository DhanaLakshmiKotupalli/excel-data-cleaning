# data_cleaning.py

import pandas as pd

# 1. Load data
df = pd.read_csv('../raw_data/amazon.csv')  # Adjust file path if needed

# 2. Display basic info
print("Initial shape:", df.shape)
print("Missing values:\n", df.isnull().sum())

# 3. Handle missing values (drop or fill as per your case)
df = df.dropna()  # Or use df.fillna('Unknown') based on your context

# 4. Remove duplicates
df = df.drop_duplicates()

# 5. Standardize column names
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

# 6. Fix text inconsistencies (example)
if 'gender' in df.columns:
    df['gender'] = df['gender'].str.strip().str.upper()

# 7. Convert dates
if 'order_date' in df.columns:
    df['order_date'] = pd.to_datetime(df['order_date'], errors='coerce')

# 8. Fix data types (example: age)
if 'age' in df.columns:
    df['age'] = pd.to_numeric(df['age'], errors='coerce')

# 9. Save cleaned data
df.to_csv('../cleaned_data/amazon_cleaned.csv', index=False)

print("✅ Data cleaned and saved successfully!")
