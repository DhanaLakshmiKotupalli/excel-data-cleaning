#   Data Cleaning in Python (Pandas)

This folder includes the Python-based data cleaning code and results.

### Script Used:
- `data_cleaning.py` � contains all steps from loading the raw file to saving the cleaned data.

### Steps in Code:
1. Loaded data using `pandas`
2. Displayed missing values and dropped/fixed them
3. Removed duplicate rows
4. Standardized column names and text
5. Converted date columns and checked data types
6. Exported a cleaned version of the dataset

### How to Use:
- Place your raw CSV file in `raw_data/`
- Run `data_cleaning.py`
- Cleaned CSV will be saved in `cleaned_data/`
